//
// Galileo.js Copyright (C) 2015  Earl C. Terwilliger II   Email:earl@microcontrollerelectronics.com
//

var port           = Number(process.argv[2]);
var app            = require('http').createServer(handler)
var io             = require('socket.io')(app);
var fs             = require('fs');
var ip             = require('ip');
var m              = require('mraa');
//var util           = require('util')
//var querystring = require('querystring');
var Server         = 'Galileo Server 1.0';
var NoticeInterval = 60 * 1000;

function handler (req, res) {
//  var qs = querystring.parse(req.url.split("?")[1]);
  fs.readFile(__dirname + '/index.html','utf8', function (err, data) {
    if (err) {
      res.writeHead(500);
      return res.end('Error loading index.html');
    }
    var myip = ip.address();
    var result = data.replace(/127.0.0.1:8888/g,myip+":"+port);
    res.writeHead(200, {'Content-Type' : "text/html; charset=utf-8"});
    res.end(result);
  });
}

function zeroFill(i) { return (i < 10 ? '0' : '') + i }

function now(days) {
  var d = new Date();
  d.setDate(d.getDate() + days);
  return d.getFullYear() + '-'
    + zeroFill((d.getMonth() + 1)) + '-'
    + zeroFill(d.getDate())        + ' '
    + zeroFill(d.getHours())       + ':'
    + zeroFill(d.getMinutes())     + ':'
    + zeroFill(d.getSeconds())      
}

function logit(socket,type,msg) {
  if (socket.request.connection.remoteAddress === undefined) { 
    IP_addr = socket.IP; 
  }
  else {
    var IP_remote  = socket.request.connection.remoteAddress;
    var IP_port    = socket.request.connection.remotePort;
    var IP_addr    = IP_remote + ":" + IP_port;
  }
  var logmsg     = { Creation_Date: '', IP_Address: '', Type: '',Message: ''};
  logmsg.Creation_Date = now(0); 
  logmsg.IP_Address    = IP_addr;
  logmsg.Type          = type;
  logmsg.Message       = msg;
  console.info(logmsg);
}

function mraa_command(msg) {
  io.emit('chat', { Message: JSON.stringify({msg: msg}) });
  if ( ((msg[1] != "digital") && (msg[1] != "analog")) ||
       ((msg[2] != "read")    && (msg[2] != "write"))  ||
       (msg.length < 3) ||
       isNaN(msg[3])
     ) {
       io.emit('chat', { Message: "Syntax: mraa digital|analog read|write pin [timer]"});
       return;
  }
  var PinNum = Number(msg[3]);
  if (msg[1] == "digital") { 
    var Pin = new m.Gpio(PinNum);
    if (msg[2] == "read") {
      Pin.dir(m.DIR_IN); 
      var Val = Pin.read();
      console.log("Pin: " + msg[3] + " Value: " + Val);
      io.emit('chat', { Message: "Digital Value of Pin:" + msg[3] + " is " + Val });
    }
    if (msg[2] == "write") {
      Pin.dir(m.DIR_OUT); 
      Pin.write(1);
      console.log("Pin: " + msg[3] + " Set to  High!");
      io.emit('chat', { Message: "Digital Pin:" + msg[3] + " set to HIGH!" });
    }
    return;
  }
  if (msg[1] == "analog") {
    var Pin = new m.Aio(PinNum);
    if (msg[2] == "read") {
      var Val  = Pin.read();
      var fVal = Pin.readFloat();
      console.log("Pin: " + msg[3] + " Analog Value: " + Val);
      console.log("Pin: " + msg[3] + " Analog Value: " + fVal.toFixed(5).toString());
      io.emit('chat', { Message: "Analog Value of Pin:" + msg[3] + " is " + Val });
      io.emit('chat', { Message: "Analog Value of Pin:" + msg[3] + " is " + fVal.tofixed(5).toString() });
    }
    return;
  }
}

if (isNaN(port)) port = 8888;
app.listen(port);
console.log(Server + " listening on Port:" + port);
console.log('MRAA Version: ' + m.getVersion());

io.on('connection', function (socket) {
  socket.IP = socket.request.connection.remoteAddress + ":" + socket.request.connection.remotePort;

  socket.interval = setInterval(function() {socket.send(Server + ' is alive! ' + now(0));},NoticeInterval);

  socket.send(Server);

  logit(socket,'connect',JSON.stringify(socket.IP));

  socket.on('serverinfo', function (data) {
    logit(socket,'ServerInfo',JSON.stringify(data));
    io.emit('chat', {Message: Server});
  });

  socket.on('message', function (msg) {
    if (msg == "") return;
    logit(socket,'Message',JSON.stringify({msg: msg}));
    console.log(JSON.stringify({msg: msg}));
    io.emit('message',msg);
  });

  socket.on('chat', function (data) {
    if (data.Message  == "") return;
    logit(socket,'Message',JSON.stringify(data));
    console.log(JSON.stringify(data));
    io.emit('chat',data);
    var msg = data.Message.split(" ");
    console.log(msg);
    if (msg[0] == "mraa") mraa_command(msg);
  });

  socket.on('disconnect', function () {
    console.log(socket.IP+" disconnected");
    logit(socket,'Disconnect','');
    clearInterval(socket.interval);
  });

  socket.on('error', function () {
    logit(socket,'Error','');
  });
});
